package model.exceptions;

import java.lang.Exception;

/**
 *	@author Oscar Casado Lorenzo
 */

/**
 * The Class BadLocationException.
 */
public class BadLocationException extends Exception{
	
	/**
	 * Instantiates a new bad location exception.
	 *
	 * @param out the out
	 */
	public BadLocationException(String out){
		
	}
}
