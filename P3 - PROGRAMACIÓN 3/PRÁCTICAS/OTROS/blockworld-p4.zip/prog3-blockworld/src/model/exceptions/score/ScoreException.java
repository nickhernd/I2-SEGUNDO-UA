package model.exceptions.score;

/**
 *	@author Oscar Casado Lorenzo
 */

/**
 * The Class ScoreException.
 */
public class ScoreException extends RuntimeException{
	
	/**
	 * Instantiates a new score exception.
	 *
	 * @param out the out
	 */
	public ScoreException(String out) {
		
	}
}
