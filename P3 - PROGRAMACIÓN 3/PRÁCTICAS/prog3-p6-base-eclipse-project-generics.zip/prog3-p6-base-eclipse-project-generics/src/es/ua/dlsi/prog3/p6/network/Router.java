package es.ua.dlsi.prog3.p6.network;

/**
 * Router device
 */
public class Router extends Device {
	/**
	 * Router device constructor
	 * @param name Device name
	 * @param address Network address
	 */
	public Router(String name, String address) {
		super(name, address);
	}

}
