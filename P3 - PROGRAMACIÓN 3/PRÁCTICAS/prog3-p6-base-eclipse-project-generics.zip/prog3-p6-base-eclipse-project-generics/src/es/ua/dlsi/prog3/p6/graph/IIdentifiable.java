package es.ua.dlsi.prog3.p6.graph;

/**
 * It guarantees the object has a unique ID
 * @author drizo
 *
 */
public interface IIdentifiable {
	int getUniqueID();
}
