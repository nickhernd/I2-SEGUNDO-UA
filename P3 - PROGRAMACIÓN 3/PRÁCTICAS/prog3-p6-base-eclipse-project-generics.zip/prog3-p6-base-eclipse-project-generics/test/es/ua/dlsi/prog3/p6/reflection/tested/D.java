package es.ua.dlsi.prog3.p6.reflection.tested;

/**
 * @author David Rizo - drizo@dlsi.ua.es
 * @created 12/11/22
 */
public class D {
    public void doD() {

    }
}
