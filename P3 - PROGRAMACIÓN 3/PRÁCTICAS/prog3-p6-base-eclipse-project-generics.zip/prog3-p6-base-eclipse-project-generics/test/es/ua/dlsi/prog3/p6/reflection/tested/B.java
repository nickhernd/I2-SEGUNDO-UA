package es.ua.dlsi.prog3.p6.reflection.tested;

/**
 * @author David Rizo - drizo@dlsi.ua.es
 * @created 12/11/22
 */
public class B {
    private C c;
    private F f;

    public B(C c, F f) {
        this.c = c;
        this.f = f;
    }
}
