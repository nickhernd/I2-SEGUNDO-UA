package es.ua.dlsi.prog3.p6.reflection.tested;

/**
 * @author David Rizo - drizo@dlsi.ua.es
 * @created 12/11/22
 */
public class C {
    private D d;

    public D getD() {
        return d;
    }

    public void setD(D d) {
        this.d = d;
    }
}
