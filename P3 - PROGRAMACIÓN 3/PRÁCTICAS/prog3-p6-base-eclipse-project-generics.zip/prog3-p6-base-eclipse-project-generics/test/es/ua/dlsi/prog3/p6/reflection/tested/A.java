package es.ua.dlsi.prog3.p6.reflection.tested;

/**
 * Class for testing purposes
 * @author David Rizo - drizo@dlsi.ua.es
 * @created 12/11/22
 */
public class A {
    private A a;

    private String string;

    private int integer;

    private B b;

    public A(B b, C c) {
        this.b = b;
    }

    public D computeD() {
        return null;
    }

    public void computeWithE(E e) {

    }
}
