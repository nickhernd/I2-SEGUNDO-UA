package es.ua.dlsi.prog3.p6.reflection.tested;

/**
 * @author David Rizo - drizo@dlsi.ua.es
 * @created 12/11/22
 */
public class E {
    private String s;
    private F f;

    public String getS() {
        return s;
    }

    public void setS(String s) {
        this.s = s;
    }

    public F getF() {
        return f;
    }

    public void setF(F f) {
        this.f = f;
    }
}
