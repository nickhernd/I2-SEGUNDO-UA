package es.ua.dlsi.prog3.p6.reflection.tested;

/**
 * @author David Rizo - drizo@dlsi.ua.es
 * @created 12/11/22
 */
public class F extends D implements Comparable<F> {
    public void doF() {

    }

    @Override
    public int compareTo(F o) {
        return 0;
    }
}
