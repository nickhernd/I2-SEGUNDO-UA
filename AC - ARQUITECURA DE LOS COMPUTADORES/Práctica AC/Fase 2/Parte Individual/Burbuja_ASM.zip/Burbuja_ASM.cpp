//OSCAR CASADO LORENZO 77580351V
#include <iostream>
#include <stdio.h>
#include <stdlib.h>
using namespace std;

int main() {
	// Declaración e inicialización del vector 
	int vector[20] = {2,30,45,2,7,4,8,1,4,5,7,9,5,4,0,6,7,6,1,3};
	__asm {
			// Cargamos en un registro, posición inicial del bucle
			mov esi, 0	
			// Cargamos en otro registro, posición final del bucle
			mov edi, 19 

		/*	recorrido: es la etiqueta correspondiente al segundo 
			bucle del pseudocódigo, es decir, el que se encarga de 
			recorrer el vector extrayendo en cada iteración las 
			parejas a analizar.
		*/
		recorrido:		
			sub edi, 1
			/*	Accedemos a la posición de memoria en la que se
				encuentra nuestro contador, es necesario tener 
				en cuenta para ello que como nuestro vector está
				compuesto por ints estos ocupan un total de 
				32 bits o lo que es lo mismo, 4 bytes. Esto 
				produce que los accesos a memoria sean así.
			*/
			mov edx, [vector+4*edi] 
			add edi, 1				
			mov eax, [vector+4*edi] 
			//Comparamos las posiciones adyacentes
			cmp edx, eax 	
			/*	Si la posición mas a la izquierda resulta ser menor
				que su sucesiva llamamos a la etiqueta intercambiar:
				para que reordenen.
			*/
			jl intercambio	
			/*	Si no es necesario el intercambio, hacemos un salto
				incondicional hacia la etiqueta decrementar: para
				reajustar los contadores
			*/
			jmp decrementar			

		incremento:	
			/*	Incrementamos el valor del registro 'esi', el cual
				controla la posición tope a la que a de llegar 
				recorrido:
			*/
			inc esi	
			// Reseteamos los contadores
			mov edi, 19 
			// Comprobamos si hemos llegado a la ultima iteración
			cmp esi, 20
			// Si no es así volvemos a ejecutar el análisis de parejas
			jl recorrido
			// Por otro lado si esto se cumple finalizamos el programa
			jmp fin		

			/*	Como explico en la documentación esta es la parte en la
				que 2 posiciones intercambian sus valores para dar 
				lugar así a la reordenación correcta de la lista
			*/
			intercambio:	
			// Como ya tenemos almacenados los valores podemos sobreescribirlos
			mov [vector+4*edi], edx;
			// Restamos 1 al contador de posición para acceder a la contigua
			sub edi, 1				
			mov [vector + 4 * edi], eax	
			// Restauramos el valor del contador al que había al instanciar la etiqueta
			add edi, 1		
			//Salto incondicional a decrementar:
			jmp decrementar 

		/*	Tanto si tenemos que intercambiar las posiciones o no, tenemos que
			decrementar el contador de posición hasta el tope anteriormente 
			mencionado, y justo de eso se encarga esta etiqueta
		*/
		decrementar:	
			dec edi		
			cmp edi, esi 
			jg recorrido 
			jmp incremento 

		/*	Para finalizar el programa lo mas común es instanciar a una 
			etiqueta vacía.
		*/
		fin: 

	}

	//Mostramos el resultado final del vector por pantalla
	for (int i = 0; i < 20; i++) 	
		printf_s(" %d ", vector[i]);	
}